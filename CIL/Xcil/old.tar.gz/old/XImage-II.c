/*
 * XImage.c
 */


#include "XImage.h"



void XDrawImage
  _P11 (( Display *, display   ),
	( Window   , window    ),
	( GC       , gc        ),
	( long     , win_x     ),
	( long     , win_y     ),
	( long     , win_xsize ),
	( long     , win_ysize ),
	( long     , type      ),
	( char **  , data      ),
	( long     , img_xsize ),
	( long     , img_ysize ))
{
  XImage *src;

  if (win_xsize <= 0 || win_ysize <= 0) return;
  if (img_xsize <= 0 || img_ysize <= 0) return;

  XImageSetColormap(display, window);

  src = XCreateImageFromData(display, win_xsize, win_ysize,
			     type, data, img_xsize, img_ysize);
  if (src == 0) return;

  XPutImage(display, window, gc, src, 0, 0,
	    win_x, win_y, win_xsize, win_ysize);

  XDestroyImage(src);
}



XImage *XCreateImageFromData
  _P7 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( long     , type      ),
       ( char **  , data      ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  long plane;

  plane = DisplayPlanes(display, DefaultScreen(display));

  XImageSetErrorPorpagate();
  XImageSetLookupTable();

  switch( plane )
    {
    case 1:
      src = XCreateImageFromData_1Plane(display, win_xsize, win_ysize,
					type, data, img_xsize, img_ysize);
      break;

    case 8:
      src = XCreateImageFromData_8Planes(display, win_xsize, win_ysize,
					 type, data, img_xsize, img_ysize);

      break;

    case 16:
      src = XCreateImageFromData_16Planes(display, win_xsize, win_ysize,
					  type, data, img_xsize, img_ysize);
      break;

    case 24:
      src = XCreateImageFromData_24Planes(display, win_xsize, win_ysize,
					  type, data, img_xsize, img_ysize);
      break;

    default:
      fprintf(stderr,
	      "error:XCreateImageFromData:I don't know this display type.\n" );
      return 0;
    }

  return src;
}



void XShowImage
  _P12 (( Display *, display   ),
	( Window   , window    ),
	( GC       , gc        ),
	( image    , img       ),
	( long     , win_x     ),
	( long     , win_y     ),
	( long     , win_xsize ),
	( long     , win_ysize ),
	( long     , img_x     ),
	( long     , img_y     ),
	( long     , img_xsize ),
	( long     , img_ysize ))
{
  image showing;

  showing = Image.create("Showing");
  ImageShowing(showing, img, img_x, img_y, img_xsize, img_ysize);
  XDrawImage(display, window, gc, win_x, win_y, win_xsize, win_ysize,
	     showing->type, showing->data, img_xsize, img_ysize);
  Image.destroy(showing);
}



void XShowImagePartOfImage
  _P8 (( Display *, display   ),
       ( Window   , window    ),
       ( GC       , gc        ),
       ( image    , img       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  Window root;
  int x, y;
  unsigned int xsize, ysize, border, depth;

  XGetGeometry(display, window, &root,
	       &x, &y, &xsize, &ysize, &border, &depth );

  XShowImage(display, window, gc, img,
	     0, 0, xsize, ysize, img_x, img_y, img_xsize, img_ysize );
}



void XShowImagePartOfWindow
  _P8 (( Display *, display   ),
       ( Window   , window    ),
       ( GC       , gc        ),
       ( image    , img       ),
       ( long     , win_x     ),
       ( long     , win_y     ),
       ( long     , win_xsize ),
       ( long     , win_ysize ))
{
  XShowImage(display, window, gc, img,
	     win_x, win_y, win_xsize, win_ysize,
	     0, 0, img->xsize, img->ysize );
}



void XShowImageFull
  _P4 (( Display *, display   ),
       ( Window   , window    ),
       ( GC       , gc        ),
       ( image    , img       ))
{
  Window root;
  int x, y;
  unsigned int xsize, ysize, border, depth;

  XGetGeometry(display, window, &root,
	       &x, &y, &xsize, &ysize, &border, &depth );

  XShowImage(display, window, gc, img,
	     0, 0, xsize, ysize, 0, 0, img->xsize, img->ysize );
}



uchar __XEPT_90[ 256 ];
uchar __XEPT_45[ 256 ];

void XImageSetErrorPorpagate()
{
  int i;

  for ( i = 0; i < 256; i++ )
    {
      __XEPT_90[i] = 7 * i / 22; /* ��, �� */
      __XEPT_45[i] = 2 * i / 22; /* ����, ���� */
    }
}



uchar XLUT_PC_UChar3[ RMAX ][ GMAX ][ BMAX ];

uchar XLUT_PC_UChar[ 256 ];
uchar XLUT_GS_UChar[ 256 ];
uchar XLUT_SG_UChar[ 256 ];

uchar XLUT_PCR[ 256 ];
uchar XLUT_PCG[ 256 ];
uchar XLUT_PCB[ 256 ];
uchar XLUT_PCRerr[ RMAX ];
uchar XLUT_PCGerr[ GMAX ];
uchar XLUT_PCBerr[ BMAX ];

void XImageSetLookupTable()
{
  static long XLookupTable_initialized = 0;
  int i, r, g, b;

  if ( XLookupTable_initialized ) return;

  for ( i = 0; i < 256; i++ )
    XLUT_PC_UChar[ i ] = MMAX * i / 256 + MBASE;

  for ( i = 0; i < 256; i++ )
    XLUT_GS_UChar[ i ] = GrayMax * i / 256 + GrayBase;

  for ( i = 0; i < 256; i++ )
    XLUT_SG_UChar[ i ] = i;

  for ( r = 0; r < RMAX; r++ )
    for ( g = 0; g < GMAX; g++ )
      for ( b = 0; b < BMAX; b++ )
	XLUT_PC_UChar3[ r ][ g ][ b ] = r * GMAX * BMAX + g * BMAX + b + CBASE;

  for ( i = 0; i < 256; i++ )
    {
      XLUT_PCR[ i ] = RMAX * i / 256;
      XLUT_PCG[ i ] = GMAX * i / 256;
      XLUT_PCB[ i ] = BMAX * i / 256;
    }

  for ( r = 0; r < RMAX; r++ )
    XLUT_PCRerr[ r ] = 256 * r / RMAX;

  for ( g = 0; g < GMAX; g++ )
    XLUT_PCGerr[ g ] = 256 * g / GMAX;

  for ( b = 0; b < BMAX; b++ )
    XLUT_PCBerr[ b ] = 256 * b / BMAX;

  XLookupTable_initialized = 1;
}
