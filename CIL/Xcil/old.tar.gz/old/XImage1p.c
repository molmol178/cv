/*
 * XImage 1 Plane
 */



#include "XImage.h"



typedef struct CallerRec {
  long type;
  XCreateImageFunc func;
} Caller;

static Caller table[] = {
  {PackedBit1,XCreateImageFromData_PackedBit1},
  {Bit1,XCreateImageFromData_Bit1},
  {Bit4,XCreateImageFromData_1Plane_Bit4},

  {Char,  XCreateImageFromData_1Plane_Char},
  {Short, XCreateImageFromData_1Plane_Short},
  {Int,   XCreateImageFromData_1Plane_Long},
  {Long,  XCreateImageFromData_1Plane_Long},
  {UChar, XCreateImageFromData_1Plane_UChar},
  {UShort,XCreateImageFromData_1Plane_UShort},
  {UInt,  XCreateImageFromData_1Plane_ULong},
  {ULong, XCreateImageFromData_1Plane_ULong},
  {Float, XCreateImageFromData_1Plane_Float},
  {Double,XCreateImageFromData_1Plane_Double},

  {Char2,  XCreateImageFromData_1Plane_Char2},
  {Short2, XCreateImageFromData_1Plane_Short2},
  {Int2,   XCreateImageFromData_1Plane_Long2},
  {Long2,  XCreateImageFromData_1Plane_Long2},
  {UChar2, XCreateImageFromData_1Plane_UChar2},
  {UShort2,XCreateImageFromData_1Plane_UShort2},
  {UInt2,  XCreateImageFromData_1Plane_ULong2},
  {ULong2, XCreateImageFromData_1Plane_ULong2},
  {Float2, XCreateImageFromData_1Plane_Float2},
  {Double2,XCreateImageFromData_1Plane_Double2},

  {Char3,  XCreateImageFromData_1Plane_Char3},
  {Short3, XCreateImageFromData_1Plane_Short3},
  {Int3,   XCreateImageFromData_1Plane_Long3},
  {Long3,  XCreateImageFromData_1Plane_Long3},
  {UChar3, XCreateImageFromData_1Plane_UChar3},
  {UShort3,XCreateImageFromData_1Plane_UShort3},
  {UInt3,  XCreateImageFromData_1Plane_ULong3},
  {ULong3, XCreateImageFromData_1Plane_ULong3},
  {Float3, XCreateImageFromData_1Plane_Float3},
  {Double3,XCreateImageFromData_1Plane_Double3}
};



XImage *XCreateImageFromData_1Plane
  _P9 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( long     , type      ),
       ( char **  , data      ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  Caller *caller;

  caller = typeselectconst( type, Caller, table );

  src = caller->func( display, win_xsize, win_ysize,
		      data, img_x, img_y, img_xsize, img_ysize );

  return src;
}
