/*
 * XImage for ushort
 */


#include "XImage.h"


static uchar3 **ushort_to_uchar3
  _P5 (( register ushort **, src       ),
       ( long              , img_x     ),
       ( long              , img_y     ),
       ( register long     , img_xsize ),
       ( register long     , img_ysize ))
{
  uchar3 **data;
  register int x, y, sx, sy, xx, yy, px, py;
  register long label;
  long label_max;
  uchar3 *cmap;

  data = typenew2( img_xsize, img_ysize, uchar3 );

  label_max = 0;
  for (y = 0; y < img_ysize; y++)
    for (x = 0; x < img_xsize; x++)
      if (src[img_y + y][img_x + x] > label_max)
	label_max = src[img_y + y][img_x + x];

  cmap = XImageMakeLabelColormap(label_max, getenv("CIL_COLORED_USHORT"));

  for ( y = 0; y < img_ysize; y++)
    {
      for ( x = 0; x < img_xsize; x++ )
	{
	  label = src[img_y + y][img_y + x];

	  if ( label == 0 )
	    {
	      data[y][x].at[0] = 100;
	      data[y][x].at[1] = 100;
	      data[y][x].at[2] = 100;
	    }
	  else
	    {
	      data[y][x] = cmap[label];
	    }
	}
    }
  typefree1(cmap);

  return data;
}



static void draw_image
  _P9 (( Display *         , display   ),
       ( register XImage * , src       ),
       ( register long     , win_xsize ),
       ( register long     , win_ysize ),
       ( register ushort **, data      ),
       ( long              , img_x     ),
       ( long              , img_y     ),
       ( long              , img_xsize ),
       ( long              , img_ysize ))
{
  register int x, y, sx, sy, xx, yy, px, py;
  register unsigned long black, white;
  register long label;

  black = BlackPixel( display, DefaultScreen( display ) );
  white = WhitePixel( display, DefaultScreen( display ) );

  for ( yy = img_y, sy = y = 0; y < win_ysize; y++, sy += img_ysize )
    {
      py = yy;
      while ( sy >= win_ysize ) { yy++; sy -= win_ysize; }

      for ( xx = img_x, sx = x = 0; x < win_xsize; x++, sx += img_xsize )
	{
	  px = xx;
	  while ( sx >= win_xsize ) { xx++; sx -= win_xsize; }

	  label = data[ yy ][ xx ];
	  if (( label == 0 ) ||
	      ( data[ yy ][ px ] != label ) ||
	      ( data[ py ][ xx ] != label ) ||
	      ( data[ py ][ px ] != label ) ||
	      ( x == 0 || y == 0 ||
	        x == ( win_xsize - 1 ) || y == ( win_ysize - 1 )))
	    XPutPixel( src, x, y, black );
	  else
	  if (( label < 0 ) && ((( y + x ) % 2 ) == 0 ))
	    XPutPixel( src, x, y, black );
	  else
	    XPutPixel( src, x, y, white );
	}
    }
}



XImage *XCreateImageFromData_1Plane_UShort
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ushort **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;

  src = XGetImage( display, DefaultRootWindow( display ),
		   0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
  draw_image( display, src, win_xsize, win_ysize,
	      org, img_x, img_y, img_xsize, img_ysize );

  return src;
}



XImage *XCreateImageFromData_8Planes_PseudoColor_UShort
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ushort **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;

  if (getenv("CIL_COLORED_USHORT") != NULL)
    {
      uchar3 **data = ushort_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_8Planes_PseudoColor_UChar3
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }
  else
    {
      src = XGetImage( display, DefaultRootWindow( display ),
		       0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
      draw_image( display, src, win_xsize, win_ysize,
		  org, img_x, img_y, img_xsize, img_ysize );
    }

  return src;
}



XImage *XCreateImageFromData_8Planes_GrayScale_UShort
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ushort **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;

  if (getenv("CIL_COLORED_USHORT") != NULL)
    {
      uchar3 **data = ushort_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_8Planes_GrayScale_UChar3
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }
  else
    {
      src = XGetImage( display, DefaultRootWindow( display ),
		      0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
      draw_image( display, src, win_xsize, win_ysize,
		 org, img_x, img_y, img_xsize, img_ysize );
    }

  return src;
}



XImage *XCreateImageFromData_8Planes_StaticGray_UShort
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ushort **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;

  if (getenv("CIL_COLORED_USHORT") != NULL)
    {
      uchar3 **data = ushort_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_8Planes_StaticGray_UChar3
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }
  else
    {
      src = XGetImage( display, DefaultRootWindow( display ),
		      0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
      draw_image( display, src, win_xsize, win_ysize,
		 org, img_x, img_y, img_xsize, img_ysize );
    }

  return src;
}



XImage *XCreateImageFromData_24Planes_UShort
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ushort **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;

  if (getenv("CIL_COLORED_USHORT") != NULL)
    {
      uchar3 **data = ushort_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_24Planes_UChar3
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }
  else
    {
      src = XGetImage( display, DefaultRootWindow( display ),
		      0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
      draw_image( display, src, win_xsize, win_ysize,
		 org, img_x, img_y, img_xsize, img_ysize );
    }

  return src;
}



XImage *XCreateImageFromData_16Planes_UShort
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ushort **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;

  if (getenv("CIL_COLORED_USHORT") != NULL)
    {
      uchar3 **data = ushort_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_16Planes_UChar3
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }
  else
    {
      src = XGetImage( display, DefaultRootWindow( display ),
		      0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
      draw_image( display, src, win_xsize, win_ysize,
		 org, img_x, img_y, img_xsize, img_ysize );
    }

  return src;
}
