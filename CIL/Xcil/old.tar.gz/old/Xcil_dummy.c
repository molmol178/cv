int __Xcil_dummy()
{
  return 0;
}

