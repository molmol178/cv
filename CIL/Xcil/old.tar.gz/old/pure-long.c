/*
 * XImage for long
 */


#include "XImage.h"
#include <stdlib.h>


#define ZP8SG (2*255/3)
#define MP8SG (255/3)
#define ZP8GS (SMAX+2*GrayMax/3)
#define MP8GS (SMAX+GrayMax/3)
#define ZP8PC (XLUT_PC_UChar3[RMAX/2][GMAX/2][BMAX/2])
#define MP8PC (XLUT_PC_UChar3[0][0][BMAX-1])
#define ZP24 (((2*255/3)<<16)|((2*255/3)<<8)|(2*255/3))
#define MP24 (0xff)
#define ZP16 (((R_MAX_16/2)<<R_SHIFT_16)|((G_MAX_16/2)<<G_SHIFT_16)|((B_MAX_16/2)<<B_SHIFT_16))
#define MP16 ((0<<R_SHIFT_16)|(0<<G_SHIFT_16)|(B_MAX_16<<B_SHIFT_16))


static void draw_image_bit1
  _P9 (( Display *         , display   ),
       ( register XImage * , src       ),
       ( register long     , win_xsize ),
       ( register long     , win_ysize ),
       ( register long **  , data      ),
       ( long              , img_x     ),
       ( long              , img_y     ),
       ( long              , img_xsize ),
       ( long              , img_ysize ))
{
  register int x, y, sx, sy, xx, yy, px, py;
  register unsigned long black, white;
  register long label;

  black = BlackPixel( display, DefaultScreen( display ) );
  white = WhitePixel( display, DefaultScreen( display ) );

  for ( yy = img_y, sy = y = 0; y < win_ysize; y++, sy += img_ysize )
    {
      py = yy;
      while ( sy >= win_ysize ) { yy++; sy -= win_ysize; }

      for ( xx = img_x, sx = x = 0; x < win_xsize; x++, sx += img_xsize )
	{
	  px = xx;
	  while ( sx >= win_xsize ) { xx++; sx -= win_xsize; }

	  label = data[ yy ][ xx ];
	  if (( label == 0 ) ||
	      ( data[ yy ][ px ] != label ) ||
	      ( data[ py ][ xx ] != label ) ||
	      ( data[ py ][ px ] != label ) ||
	      ( x == 0 || y == 0 ||
	        x == ( win_xsize - 1 ) || y == ( win_ysize - 1 )))
	    XPutPixel( src, x, y, black );
	  else
	  if (( label < 0 ) && ((( y + x ) % 2 ) == 0 ))
	    XPutPixel( src, x, y, black );
	  else
	    XPutPixel( src, x, y, white );
	}
    }
}


static void draw_image
  _P11 (( Display *         , display     ),
	( register XImage * , src         ),
	( register long     , win_xsize   ),
	( register long     , win_ysize   ),
	( register long **  , data        ),
	( long              , img_x       ),
	( long              , img_y       ),
	( long              , img_xsize   ),
	( long              , img_ysize   ),
	( unsigned long     , zero_pixel  ),
	( unsigned long     , minus_pixel ))
{
  register int x, y, sx, sy, xx, yy, px, py;
  register unsigned long black, white;
  register long label;

  black = BlackPixel( display, DefaultScreen( display ) );
  white = WhitePixel( display, DefaultScreen( display ) );

  for ( yy = img_y, sy = y = 0; y < win_ysize; y++, sy += img_ysize )
    {
      py = yy;
      while ( sy >= win_ysize ) { yy++; sy -= win_ysize; }

      for ( xx = img_x, sx = x = 0; x < win_xsize; x++, sx += img_xsize )
	{
	  px = xx;
	  while ( sx >= win_xsize ) { xx++; sx -= win_xsize; }

	  label = data[ yy ][ xx ];
	  if (( data[ yy ][ px ] != label ) ||
	      ( data[ py ][ xx ] != label ) ||
	      ( data[ py ][ px ] != label ) ||
	      ( x == 0 || y == 0 ||
	        x == ( win_xsize - 1 ) || y == ( win_ysize - 1 )))
	    XPutPixel( src, x, y, black );
	  else
	  if ( label == 0 )
	    {
	      XPutPixel( src, x, y, zero_pixel );
	    }
	  else
	  if ( label < 0 )
	    {
	      XPutPixel( src, x, y, minus_pixel );
	    }
	  else
	    XPutPixel( src, x, y, white );
	}
    }
}


XImage *XCreateImageFromData_1Plane_Label
  _P8 (( Display * , display   ),
       ( long      , win_xsize ),
       ( long      , win_ysize ),
       ( long   ** , org       ),
       ( long      , img_x     ),
       ( long      , img_y     ),
       ( long      , img_xsize ),
       ( long      , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  src = XGetImage( display, DefaultRootWindow( display ),
		  0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
  draw_image_bit1( display, src, win_xsize, win_ysize,
		  org, img_x, img_y, img_xsize, img_ysize );

  return src;
}


XImage *XCreateImageFromData_8Planes_PseudoColor_Label
  _P8 (( Display * , display   ),
       ( long      , win_xsize ),
       ( long      , win_ysize ),
       ( long   ** , org       ),
       ( long      , img_x     ),
       ( long      , img_y     ),
       ( long      , img_xsize ),
       ( long      , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  src = XGetImage( display, DefaultRootWindow( display ),
		   0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
  draw_image( display, src, win_xsize, win_ysize,
	      org, img_x, img_y, img_xsize, img_ysize, ZP8PC, MP8PC );

  return src;
}


XImage *XCreateImageFromData_8Planes_GrayScale_Label
  _P8 (( Display * , display   ),
       ( long      , win_xsize ),
       ( long      , win_ysize ),
       ( long   ** , org       ),
       ( long      , img_x     ),
       ( long      , img_y     ),
       ( long      , img_xsize ),
       ( long      , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  src = XGetImage( display, DefaultRootWindow( display ),
		   0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
  draw_image( display, src, win_xsize, win_ysize,
	      org, img_x, img_y, img_xsize, img_ysize, ZP8GS, MP8GS );

  return src;
}


XImage *XCreateImageFromData_8Planes_StaticGray_Label
  _P8 (( Display * , display   ),
       ( long      , win_xsize ),
       ( long      , win_ysize ),
       ( long   ** , org       ),
       ( long      , img_x     ),
       ( long      , img_y     ),
       ( long      , img_xsize ),
       ( long      , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  src = XGetImage( display, DefaultRootWindow( display ),
		   0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
  draw_image( display, src, win_xsize, win_ysize,
	      org, img_x, img_y, img_xsize, img_ysize, ZP8SG, MP8SG );

  return src;
}


XImage *XCreateImageFromData_24Planes_Label
  _P8 (( Display * , display   ),
       ( long      , win_xsize ),
       ( long      , win_ysize ),
       ( long   ** , org       ),
       ( long      , img_x     ),
       ( long      , img_y     ),
       ( long      , img_xsize ),
       ( long      , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  src = XGetImage( display, DefaultRootWindow( display ),
		   0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
  draw_image( display, src, win_xsize, win_ysize,
	      org, img_x, img_y, img_xsize, img_ysize, ZP24, MP24 );

  return src;
}


XImage *XCreateImageFromData_16Planes_Label
  _P8 (( Display * , display   ),
       ( long      , win_xsize ),
       ( long      , win_ysize ),
       ( long   ** , org       ),
       ( long      , img_x     ),
       ( long      , img_y     ),
       ( long      , img_xsize ),
       ( long      , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  src = XGetImage( display, DefaultRootWindow( display ),
		   0, 0, win_xsize,win_ysize,AllPlanes,ZPixmap);
  draw_image( display, src, win_xsize, win_ysize,
	      org, img_x, img_y, img_xsize, img_ysize, ZP16, MP16 );

  return src;
}
