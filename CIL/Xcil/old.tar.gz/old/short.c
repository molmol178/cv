/*
 * XImage for short
 */


#include "XImage.h"
#include <math.h>
#include <stdlib.h>


static uchar3 **short_to_uchar3
  _P5 (( register short **, src       ),
       ( long             , img_x     ),
       ( long             , img_y     ),
       ( register long    , img_xsize ),
       ( register long    , img_ysize ))
{
  uchar3 **data;
  register int x, y, sx, sy, xx, yy, px, py;
  register unsigned long black, white;
  register long label;
  long label_max;
  uchar3 *cmap;

  data = typenew2( img_xsize, img_ysize, uchar3 );

  label_max = 0;
  for (y = 0; y < img_ysize; y++)
    for (x = 0; x < img_xsize; x++)
      if (src[img_y + y][img_x + x] > label_max)
	label_max = src[img_y + y][img_x + x];

  cmap = XImageMakeLabelColormap(label_max, getenv("CIL_COLORED_SHORT"));

  for ( y = 0; y < img_ysize; y++)
    {
      for ( x = 0; x < img_xsize; x++ )
	{
	  label = src[img_y + y][img_y + x];

	  if ( label == 0 )
	    {
	      data[y][x].at[0] = 100;
	      data[y][x].at[1] = 100;
	      data[y][x].at[2] = 100;
	    }
	  else
	  if ( label < 0 )
	    {
	      data[y][x].at[0] = 50;
	      data[y][x].at[1] = 50;
	      data[y][x].at[2] = 50;
	    }
	  else
	    {
	      data[y][x] = cmap[label];
	    }
	}
    }
  typefree1(cmap);

  return data;
}



static uchar **short_to_uchar
  _P5 (( register short ** , src       ),
       ( long              , img_x     ),
       ( long              , img_y     ),
       ( register long     , img_xsize ),
       ( register long     , img_ysize ))
{
  register uchar **data;
  register int x, y;

  long minus;
  double p, mag_max, mag;

  data = typenew2( img_xsize, img_ysize, uchar );

  mag_max = src[img_y][img_x];
  minus = 0;
  for ( y = 0; y < img_ysize; y++ )
    for ( x = 0; x < img_xsize; x++ )
      {
	p = src[img_y + y][img_x + x];
	if (p < 0) minus = 1;
	mag = fabs(p);
	if (mag_max < mag) mag_max = mag;
      }

  for ( y = 0; y < img_ysize; y++ )
    for ( x = 0; x < img_xsize; x++ )
      {
	p = src[img_y + y][img_x + x];

	if (minus)
	  {
	    data[y][x] = 127 * p / mag_max + 127;
	  }
	else
	  {
	    data[y][x] = 255 * p / mag_max;
	  }
      }
  return data;
}


XImage *XCreateImageFromData_1Plane_Short
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( short ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;

  if (getenv("CIL_COLORED_SHORT") == NULL)
    {
      uchar **data = short_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_1Plane_UChar
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }
  else
    {
      uchar3 **data = short_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_1Plane_UChar3
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }

  return src;
}



XImage *XCreateImageFromData_8Planes_PseudoColor_Short
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( short ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;

  if (getenv("CIL_COLORED_SHORT") == NULL)
    {
      uchar **data = short_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_8Planes_PseudoColor_UChar
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }
  else
    {
      uchar3 **data = short_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_8Planes_PseudoColor_UChar3
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }

  return src;
}



XImage *XCreateImageFromData_8Planes_GrayScale_Short
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( short ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;

  if (getenv("CIL_COLORED_SHORT") == NULL)
    {
      uchar **data = short_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_8Planes_GrayScale_UChar
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }
  else
    {
      uchar3 **data = short_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_8Planes_GrayScale_UChar3
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }

  return src;
}



XImage *XCreateImageFromData_8Planes_StaticGray_Short
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( short ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;

  if (getenv("CIL_COLORED_SHORT") == NULL)
    {
      uchar **data = short_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_8Planes_StaticGray_UChar
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }
  else
    {
      uchar3 **data = short_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_8Planes_StaticGray_UChar3
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }

  return src;
}



XImage *XCreateImageFromData_16Planes_Short
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( short ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar **data;

  if (getenv("CIL_COLORED_SHORT") == NULL)
    {
      uchar **data = short_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_16Planes_UChar
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }
  else
    {
      uchar3 **data = short_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_16Planes_UChar3
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }

  return src;
}



XImage *XCreateImageFromData_24Planes_Short
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( short ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;

  if (getenv("CIL_COLORED_SHORT") == NULL)
    {
      uchar **data = short_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_24Planes_UChar
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }
  else
    {
      uchar3 **data = short_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
      src = XCreateImageFromData_24Planes_UChar3
	(display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
      typefree2( data );
    }

  return src;
}
