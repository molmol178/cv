/*
 * filename : any1.c
 * author   : Takahiro Sugiyama
 * date     : Friday, November 17 1995
 * describe : 1-D any image type
 */


#include "XImage.h"


