/*
 * XImage for float3
 */


#include "XImage.h"
#include <math.h>


static uchar3 **float3_to_uchar3
  _P5 (( register float3 **, src       ),
       ( long              , img_x     ),
       ( long              , img_y     ),
       ( register long     , img_xsize ),
       ( register long     , img_ysize ))
{
  register uchar3 **data;
  register int x, y;

  long minus;
  double p0, p1, p2;
  double mag_max, mag_min, mag_range, mag, mag_offset;

  p0 = src[img_y][img_x].at[0];
  p1 = src[img_y][img_x].at[1];
  p2 = src[img_y][img_x].at[2];
  mag_max = mag_min = p0*p0 + p1*p1 + p2*p2;
  minus = 0;
  for ( y = 0; y < img_ysize; y++ )
    for ( x = 0; x < img_xsize; x++ )
      {
	p0 = src[img_y + y][img_x + x].at[0];
	p1 = src[img_y + y][img_x + x].at[1];
	p2 = src[img_y + y][img_x + x].at[2];
	if ((p0 < 0) || (p1 < 0) || (p2 < 0)) minus = 1;
	mag = p0*p0 + p1*p1 + p2*p2;
	if (mag_max < mag) mag_max = mag; else
	if (mag_min > mag) mag_min = mag;
      }
  mag_max = sqrt(mag_max);
  mag_min = sqrt(mag_min);
  mag_range = (mag_max - mag_min);

  data = typenew2(img_xsize, img_ysize, uchar3);

  if (minus)
    {
      mag_max = 127.0*sqrt(3.0)/mag_range;
      mag_offset = 127;
    }
  else
    {
      mag_max = 255.0*sqrt(3.0)/mag_range;
      mag_offset = 0;
    }
  mag_min = mag_max * mag_min;

  for ( y = 0; y < img_ysize; y++ )
    for ( x = 0; x < img_xsize; x++ )
      {
	p0 = src[img_y + y][img_x + x].at[0];
	p1 = src[img_y + y][img_x + x].at[1];
	p2 = src[img_y + y][img_x + x].at[2];

	mag = sqrt(p0*p0 + p1*p1 + p2*p2);
	if (mag != 0) mag = mag_max - mag_min/mag;
	p0 = p0 * mag + mag_offset;
	p1 = p1 * mag + mag_offset;
	p2 = p2 * mag + mag_offset;

	if (p0 > 255) p0 = 255; else if (p0 < 0) p0 = 0;
	if (p1 > 255) p1 = 255; else if (p1 < 0) p1 = 0;
	if (p2 > 255) p2 = 255; else if (p2 < 0) p2 = 0;

	data[y][x].at[0] = p0;
	data[y][x].at[1] = p1;
	data[y][x].at[2] = p2;
      }
  return data;
}


XImage *XCreateImageFromData_1Plane_Float3
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float3 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = float3_to_uchar3( org, img_x, img_y, img_xsize, img_ysize );
  src = XCreateImageFromData_1Plane_UChar3
    ( display, win_xsize, win_ysize, data, 0, 0, img_xsize, img_ysize);
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_8Planes_PseudoColor_Float3
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float3 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = float3_to_uchar3( org, img_x, img_y, img_xsize, img_ysize );
  src = XCreateImageFromData_8Planes_PseudoColor_UChar3
    ( display, win_xsize, win_ysize, data, 0, 0, img_xsize, img_ysize );
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_8Planes_GrayScale_Float3
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float3 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = float3_to_uchar3( org, img_x, img_y, img_xsize, img_ysize );
  src = XCreateImageFromData_8Planes_GrayScale_UChar3
    ( display, win_xsize, win_ysize, data, 0, 0, img_xsize, img_ysize );
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_8Planes_StaticGray_Float3
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float3 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = float3_to_uchar3( org, img_x, img_y, img_xsize, img_ysize );
  src = XCreateImageFromData_8Planes_StaticGray_UChar3
    ( display, win_xsize, win_ysize, data, 0, 0, img_xsize, img_ysize );
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_24Planes_Float3
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float3 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = float3_to_uchar3( org, img_x, img_y, img_xsize, img_ysize );
  src = XCreateImageFromData_24Planes_UChar3
    ( display, win_xsize, win_ysize, data, 0, 0, img_xsize, img_ysize );
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_16Planes_Float3
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float3 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = float3_to_uchar3( org, img_x, img_y, img_xsize, img_ysize );
  src = XCreateImageFromData_16Planes_UChar3
    ( display, win_xsize, win_ysize, data, 0, 0, img_xsize, img_ysize );
  typefree2( data );

  return src;
}
