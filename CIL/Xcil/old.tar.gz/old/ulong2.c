/*
 * XImage for ulong2
 */



#include "XImage.h"
#include <math.h>


static uchar3 **ulong2_to_uchar3
  _P5 (( register ulong2 **, src       ),
       ( long              , img_x     ),
       ( long              , img_y     ),
       ( register long     , img_xsize ),
       ( register long     , img_ysize ))
{
  register int x, y;
  register uchar3 **data;
  register uchar *u;

  double px, py;
  double mag, mag_max;

  mag_max = 0;
  for ( y = 0; y < img_ysize; y++ )
    for ( x = 0; x < img_xsize; x++ )
      {
	px = src[ img_y + y ][ img_x + x ].at[0];
	py = src[ img_y + y ][ img_x + x ].at[1];
	mag = px*px + py*py;
	if (mag_max < mag) mag_max = mag;
      }
  mag_max = sqrt(mag_max);

  data = typenew2( img_xsize, img_ysize, uchar3 );

  for ( y = 0; y < img_ysize; y++ )
    for ( x = 0; x < img_xsize; x++ )
      {
	double r, g, b;
	double vx, vy;
	double theta, radius;

	px = src[ img_y + y ][ img_x + x ].at[0];
	py = src[ img_y + y ][ img_x + x ].at[1];
	u = data[ y ][ x ].at;

	vx = - px / mag_max;
	vy = py / mag_max;

	if ((vy == 0) && (vx == 0))
	  {
	    u[0] = 255;
	    u[1] = 255;
	    u[2] = 255;
	    continue;
	  }
	theta = (vy == 0) ? ((vx>0)?0:M_PI) : atan2(vy, vx);
	if (theta < 0) theta = 2*M_PI + theta;
	radius = sqrt(vx*vx+vy*vy);
	if (theta <= 2*M_PI/3)
	  {
	    b = (1.0 - radius) / 1.0;
	    r = radius*(cos(theta) + sin(theta) / tan(M_PI/3.0)) + b;
	    g = radius*(cos(2*M_PI/3.0-theta) + sin(2*M_PI/3.0-theta) / tan(M_PI/3.0)) + b;
	  }
	else
	if (4*M_PI/3 <= theta) /* R--B */
	  {
	    theta -= 4*M_PI/3;
	    g = (1.0 - radius) / 1.0;
	    b = radius*(cos(theta) + sin(theta) / tan(M_PI/3.0)) + g;
	    r = radius*(cos(2*M_PI/3.0-theta) + sin(2*M_PI/3.0-theta) / tan(M_PI/3.0)) + g;
	  }
	else /* B--G */
	  {
	    theta -= 2*M_PI/3;
	    r = (1.0 - radius) / 1.0;
	    g = radius*(cos(theta) + sin(theta) / tan(M_PI/3.0)) + r;
	    b = radius*(cos(2*M_PI/3.0-theta) + sin(2*M_PI/3.0-theta) / tan(M_PI/3.0)) + r;
	  }

	r = 255 * r; if (r > 255) r = 255; else if (r < 0) r = 0;
	g = 255 * g; if (g > 255) g = 255; else if (g < 0) g = 0;
	b = 255 * b; if (b > 255) b = 255; else if (b < 0) b = 0;

	u[0] = r;
	u[1] = g;
	u[2] = b;
      }

  return data;
}


XImage *XCreateImageFromData_1Plane_ULong2
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ulong2 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = ulong2_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_1Plane_UChar3
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_8Planes_PseudoColor_ULong2
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ulong2 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = ulong2_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_8Planes_PseudoColor_UChar3
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_8Planes_GrayScale_ULong2
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ulong2 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = ulong2_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_8Planes_GrayScale_UChar3
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_8Planes_StaticGray_ULong2
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ulong2 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = ulong2_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_8Planes_StaticGray_UChar3
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_24Planes_ULong2
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ulong2 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = ulong2_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_24Planes_UChar3
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_16Planes_ULong2
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( ulong2 **, org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar3 **data;

  data = ulong2_to_uchar3(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_16Planes_UChar3
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}
