/*
 * XImage 24 Planes
 */



#include "XImage.h"



typedef struct CallerRec {
  long type;
  XCreateImageFunc func;
} Caller;



static Caller table[] = {
  {PackedBit1,XCreateImageFromData_PackedBit1},
  {Bit1,XCreateImageFromData_Bit1},
  {Bit4,XCreateImageFromData_24Planes_Bit4},

  {Char,  XCreateImageFromData_24Planes_Char},
  {Short, XCreateImageFromData_24Planes_Short},
  {Int,   XCreateImageFromData_24Planes_Long},
  {Long,  XCreateImageFromData_24Planes_Long},
  {UChar, XCreateImageFromData_24Planes_UChar},
  {UShort,XCreateImageFromData_24Planes_UShort},
  {UInt,  XCreateImageFromData_24Planes_ULong},
  {ULong, XCreateImageFromData_24Planes_ULong},
  {Float, XCreateImageFromData_24Planes_Float},
  {Double,XCreateImageFromData_24Planes_Double},

  {Char2,  XCreateImageFromData_24Planes_Char2},
  {Short2, XCreateImageFromData_24Planes_Short2},
  {Int2,   XCreateImageFromData_24Planes_Long2},
  {Long2,  XCreateImageFromData_24Planes_Long2},
  {UChar2, XCreateImageFromData_24Planes_UChar2},
  {UShort2,XCreateImageFromData_24Planes_UShort2},
  {UInt2,  XCreateImageFromData_24Planes_ULong2},
  {ULong2, XCreateImageFromData_24Planes_ULong2},
  {Float2, XCreateImageFromData_24Planes_Float2},
  {Double2,XCreateImageFromData_24Planes_Double2},

  {Char3,  XCreateImageFromData_24Planes_Char3},
  {Short3, XCreateImageFromData_24Planes_Short3},
  {Int3,   XCreateImageFromData_24Planes_Long3},
  {Long3,  XCreateImageFromData_24Planes_Long3},
  {UChar3, XCreateImageFromData_24Planes_UChar3},
  {UShort3,XCreateImageFromData_24Planes_UShort3},
  {UInt3,  XCreateImageFromData_24Planes_ULong3},
  {ULong3, XCreateImageFromData_24Planes_ULong3},
  {Float3, XCreateImageFromData_24Planes_Float3},
  {Double3,XCreateImageFromData_24Planes_Double3}
};



XImage *XCreateImageFromData_24Planes
  _P9 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( long     , type      ),
       ( char **  , data      ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  Caller *caller;

  caller = typeselectconst( type, Caller, table );
  src = caller->func( display, win_xsize, win_ysize,
		      data, img_x, img_y, img_xsize, img_ysize );

  return src;
}
