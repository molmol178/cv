/*
 * XImage for bit4
 */



#include "XImage.h"



XImage *XCreateImageFromData_1Plane_Bit4
  _P8 (( Display *        , display   ),
       ( register long    , win_xsize ),
       ( register long    , win_ysize ),
       ( register uchar **, data      ),
       ( long             , img_x     ),
       ( long             , img_y     ),
       ( long             , img_xsize ),
       ( long             , img_ysize ))
{
  register XImage *src;
  int x,y,sx,sy;
  unsigned long pixel;

  unsigned long black = BlackPixel(display,DefaultScreen(display));
  unsigned long white = WhitePixel(display,DefaultScreen(display));
  long ps;
  long **err = typenew2( win_xsize + 2, 2, long );
  long *now  = err[1] + 1;
  long *down = err[0] + 1;

  src = XGetImage(display,DefaultRootWindow(display),
		  0,0,win_xsize,win_ysize,AllPlanes,ZPixmap);

  for (x = 0; x < win_xsize + 2; x++)
    err[0][x] = err[1][x] = 0;

  for (sy = 0,y = 0; y < win_ysize; y++)
    {
      int yy = img_y + sy / win_ysize;
      {long *tmp = now; now = down; down = tmp;}
      down[-1] = down[0] = 0;
      for (ps = 0,sx = 0,x = 0; x < win_xsize; x++)
	{
	  int xx = img_x + sx / win_xsize;

	  {
	    ps += data[yy][xx] + now[x];
	    if (ps >= 15)
	      {pixel = white;ps -= 15;}
	    else
	      {pixel = black;}
	    down[x+1] = 2 * ps / 11;
	    down[x-1] += down[x+1];
	    ps = 7 * ps / 22;
	    down[x] += ps;
	  }

	  XPutPixel(src,x,y,pixel);
	  sx += img_xsize;
	}
      sy += img_ysize;
    }
  typefree2( err );

  return src;
}



XImage *XCreateImageFromData_8Planes_PseudoColor_Bit4
  _P8 (( Display *        , display   ),
       ( register long    , win_xsize ),
       ( register long    , win_ysize ),
       ( register uchar **, data      ),
       ( long             , img_x     ),
       ( long             , img_y     ),
       ( long             , img_xsize ),
       ( long             , img_ysize ))
{
  register XImage *src;
  int x,y,sx,sy;
  unsigned long pixel;

  src = XGetImage(display,DefaultRootWindow(display),
		  0,0,win_xsize,win_ysize,AllPlanes,ZPixmap);

  for (sy = 0,y = 0; y < win_ysize; y++)
    {
      int yy = img_y + sy / win_ysize;
      for (sx = 0,x = 0; x < win_xsize; x++)
	{
	  int xx = img_x + sx / win_xsize;

	  {
	    pixel = (MMAX - 1) * (long)data[yy][xx] / 15 + MBASE;
	  }

	  XPutPixel(src,x,y,pixel);
	  sx += img_xsize;
	}
      sy += img_ysize;
    }

  return src;
}



XImage *XCreateImageFromData_8Planes_GrayScale_Bit4
  _P8 (( Display *        , display   ),
       ( register long    , win_xsize ),
       ( register long    , win_ysize ),
       ( register uchar **, data      ),
       ( long             , img_x     ),
       ( long             , img_y     ),
       ( long             , img_xsize ),
       ( long             , img_ysize ))
{
  register XImage *src;
  int x,y,sx,sy;
  unsigned long pixel;

  src = XGetImage(display,DefaultRootWindow(display),
		  0,0,win_xsize,win_ysize,AllPlanes,ZPixmap);

  for (sy = 0,y = 0; y < win_ysize; y++)
    {
      int yy = img_y + sy / win_ysize;
      for (sx = 0,x = 0; x < win_xsize; x++)
	{
	  int xx = img_x + sx / win_xsize;

	  {
	    pixel = (GrayMax - 1) * (long)data[yy][xx] / 15 + GrayBase;
	  }

	  XPutPixel(src,x,y,pixel);
	  sx += img_xsize;
	}
      sy += img_ysize;
    }

  return src;
}



XImage *XCreateImageFromData_8Planes_StaticGray_Bit4
  _P8 (( Display *        , display   ),
       ( register long    , win_xsize ),
       ( register long    , win_ysize ),
       ( register uchar **, data      ),
       ( long             , img_x     ),
       ( long             , img_y     ),
       ( long             , img_xsize ),
       ( long             , img_ysize ))
{
  register XImage *src;
  int x,y,sx,sy;

  src = XGetImage(display,DefaultRootWindow(display),
		  0,0,win_xsize,win_ysize,AllPlanes,ZPixmap);

  for (sy = 0,y = 0; y < win_ysize; y++)
    {
      int yy = img_y + sy / win_ysize;
      for (sx = 0,x = 0; x < win_xsize; x++)
	{
	  int xx = img_x + sx / win_xsize;
	  XPutPixel(src,x,y,255 * (long)data[yy][xx] / 15);
	  sx += img_xsize;
	}
      sy += img_ysize;
    }

  return src;
}



XImage *XCreateImageFromData_24Planes_Bit4
  _P8 (( Display *        , display   ),
       ( register long    , win_xsize ),
       ( register long    , win_ysize ),
       ( register uchar **, data      ),
       ( long             , img_x     ),
       ( long             , img_y     ),
       ( long             , img_xsize ),
       ( long             , img_ysize ))
{
  register XImage *src;
  int x,y,sx,sy;
  unsigned long pixel;

  src = XGetImage(display,DefaultRootWindow(display),
		  0,0,win_xsize,win_ysize,AllPlanes,ZPixmap);

  for (sy = 0,y = 0; y < win_ysize; y++)
    {
      int yy = img_y + sy / win_ysize;
      for (sx = 0,x = 0; x < win_xsize; x++)
	{
	  int xx = img_x + sx / win_xsize;

	  {
	    unsigned long p;
	    p = 255 * (long)data[yy][xx] / 15;
	    pixel = (p) | (p << 8) | (p << 16);
	  }

	  XPutPixel(src,x,y,pixel);
	  sx += img_xsize;
	}
      sy += img_ysize;
    }

  return src;
}



XImage *XCreateImageFromData_16Planes_Bit4
  _P8 (( Display *        , display   ),
       ( register long    , win_xsize ),
       ( register long    , win_ysize ),
       ( register uchar **, data      ),
       ( long             , img_x     ),
       ( long             , img_y     ),
       ( long             , img_xsize ),
       ( long             , img_ysize ))
{
  register XImage *src;
  int x,y,sx,sy;
  unsigned long pixel;

  src = XGetImage(display,DefaultRootWindow(display),
		  0,0,win_xsize,win_ysize,AllPlanes,ZPixmap);

  for (sy = 0,y = 0; y < win_ysize; y++)
    {
      int yy = img_y + sy / win_ysize;
      for (sx = 0,x = 0; x < win_xsize; x++)
	{
	  int xx = img_x + sx / win_xsize;

	  {
	    unsigned long r, g, b;
	    r = R_MAX_16 * (long)data[yy][xx] / 15;
	    g = G_MAX_16 * (long)data[yy][xx] / 15;
	    b = B_MAX_16 * (long)data[yy][xx] / 15;
	    pixel = (r << R_SHIFT_16)|(g << G_SHIFT_16)|(g << G_SHIFT_16);
	  }

	  XPutPixel(src,x,y,pixel);
	  sx += img_xsize;
	}
      sy += img_ysize;
    }

  return src;
}
