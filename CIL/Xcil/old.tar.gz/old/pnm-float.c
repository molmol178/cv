/*
 *  float to pnm
 */


#include "misc/memlib.h"
#include <math.h>


static uchar3 **ushort_to_uchar3_data
  _P6 (( register float **, src       ),
       ( long             , img_x     ),
       ( long             , img_y     ),
       ( register long    , img_xsize ),
       ( register long    , img_ysize ),
       ( double           , max       ))
{
  uchar3 **data;
  register int x, y, sx, sy, xx, yy, px, py;
  double f, f_max;
  uchar3 *cmap;

  data = typenew2( img_xsize, img_ysize, uchar3 );

  if (max == CIL_DP_UNDEF)
    {
      f_max = 0;
      for (y = 0; y < img_ysize; y++)
	for (x = 0; x < img_xsize; x++)
	  {
	    f = src[img_y + y][img_x + x];
	    if (f < 0) minus = 1;
	    f = fabs(f);
	    if (f > f_max) f_max = f
	  }
    }
  else
    f_max = max;

  cmap = XGetFeatureColormap(CIL_DP_FEATURE_COLOR_NUM);

  for ( y = 0; y < img_ysize; y++)
    for ( x = 0; x < img_xsize; x++ )
      {
	f = src[img_y + y][img_y + x];

	if (minus)
	  {
	    index = CIL_DP_FEATURE_COLOR_MAX/2 * f / f_max + CIL_DP_FEATURE_COLOR_MAX/2;
	  }
	else
	  {
	    index = CIL_DP_FEATURE_COLOR_MAX * f / f_max;
	  }
	if (index > CIL_DP_FEATURE_COLOR_MAX) index = CIL_DP_FEATURE_COLOR_MAX; else
	if (index < 0) index = 0;
	data[y][x] = cmap[index];
      }

  typefree1(cmap);

  return data;
}



uchar **float_to_uchar_data
  _P6 (( register float **, src       ),
       ( long             , img_x     ),
       ( long             , img_y     ),
       ( register long    , img_xsize ),
       ( register long    , img_ysize ),
       ( double           , max       ))
{
  register uchar **data;
  register int x, y;

  long minus;
  double p, max;
  long pixel;

  data = typenew2( img_xsize, img_ysize, uchar );

  if (max != CIL_DP_UNDEF)
    {
      max = src[img_y][img_x];
      minus = 0;
      for ( y = 0; y < img_ysize; y++ )
	for ( x = 0; x < img_xsize; x++ )
	  {
	    p = src[img_y + y][img_x + x];
	    if (p < 0) minus = 1;
	    p = fabs(p);
	    if (max < p) max = p;
	  }
    }
  if (max == 0) max = 1;

  for ( y = 0; y < img_ysize; y++ )
    for ( x = 0; x < img_xsize; x++ )
      {
	p = src[img_y + y][img_x + x];

	if (minus)
	  {
	    pixel = 127 * p / max + 127;
	  }
	else
	  {
	    pixel = 255 * p / max;
	  }
	if (pixel > 255) pixel = 255; else
	if (pixel < 0) pixel = 0;
	data[y][x] = pixel;
      }

  return data;
}



XImage *XCreateImageFromData_Float
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  double max;

  D_property = DisplayPropety(CIL_DP_FLOAT_ENV, &max);
  switch (D_property)
    {
    case CIL_DISP_FEATURE:
      {
	uchar3 **data;
	data = float_to_uchar3_data(org,img_x,img_y,img_xsize,img_ysize,max);
	src = XCreateImage_UChar3(display,win_xsize,win_ysize,
				  data,0,0,img_xsize,img_ysize);
	typefree2( data );
      }
      break;

    case CIL_DISP_FONT:
    case CIL_DISP_LABEL:
    case CIL_DISP_COLORED:
      fprintf(stderr, "invalid display property\n");
      fprintf(stderr, "check your environment %s\n", CIL_DP_FLOAT_ENV);

    case CIL_DISP_GRAY:
    default:
      {
	uchar **data;
	data = float_to_uchar_data(org,img_x,img_y,img_xsize,img_ysize,max);
	src = XCreateImage_UChar(display,win_xsize,win_ysize,
				 data,0,0,img_xsize,img_ysize);
	typefree2( data );
      }
      break;
    }

  return src;
}
