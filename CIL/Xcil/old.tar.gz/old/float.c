/*
 * XImage for float
 */


#include "XImage.h"
#include <math.h>


static uchar **float_to_uchar
  _P5 (( register float **, src       ),
       ( long             , img_x     ),
       ( long             , img_y     ),
       ( register long    , img_xsize ),
       ( register long    , img_ysize ))
{
  register uchar **data;
  register int x, y;

  long minus;
  double p, mag_max, mag;

  data = typenew2( img_xsize, img_ysize, uchar );

  mag_max = src[img_y][img_x];
  minus = 0;
  for ( y = 0; y < img_ysize; y++ )
    for ( x = 0; x < img_xsize; x++ )
      {
	p = src[img_y + y][img_x + x];
	if (p < 0) minus = 1;
	mag = fabs(p);
	if (mag_max < mag) mag_max = mag;
      }

  for ( y = 0; y < img_ysize; y++ )
    for ( x = 0; x < img_xsize; x++ )
      {
	p = src[img_y + y][img_x + x];

	if (minus)
	  {
	    data[y][x] = 127 * p / mag_max + 127;
	  }
	else
	  {
	    data[y][x] = 255 * p / mag_max;
	  }
      }
  return data;
}


XImage *XCreateImageFromData_1Plane_Float
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar **data;

  data = float_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_1Plane_UChar
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_8Planes_PseudoColor_Float
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar **data;

  data = float_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_8Planes_PseudoColor_UChar
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_8Planes_GrayScale_Float
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar **data;

  data = float_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_8Planes_GrayScale_UChar
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_8Planes_StaticGray_Float
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar **data;

  data = float_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_8Planes_StaticGray_UChar
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_16Planes_Float
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar **data;

  data = float_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_16Planes_UChar
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}



XImage *XCreateImageFromData_24Planes_Float
  _P8 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( float ** , org       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  uchar **data;

  data = float_to_uchar(org,img_x,img_y,img_xsize,img_ysize);
  src = XCreateImageFromData_24Planes_UChar
    (display,win_xsize,win_ysize,data,0,0,img_xsize,img_ysize);
  typefree2( data );

  return src;
}
