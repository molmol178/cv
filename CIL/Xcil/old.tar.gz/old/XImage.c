/*
 * XImage.c
 */


#include "XImage.h"



void XDrawImage
  _P13 (( Display *, display   ),
	( Window   , window    ),
	( GC       , gc        ),
	( long     , type      ),
	( char **  , data      ),
	( long     , win_x     ),
	( long     , win_y     ),
	( long     , win_xsize ),
	( long     , win_ysize ),
	( long     , img_x     ),
	( long     , img_y     ),
	( long     , img_xsize ),
	( long     , img_ysize ))
{
  XImage *src;

  if ( win_xsize <= 0 || win_ysize <= 0 ) return;
  if ( img_xsize <= 0 || img_ysize <= 0 ) return;

  XImageSetColormap( display, window );

  src = XCreateImageFromData( display, win_xsize, win_ysize, type, data,
			      img_x, img_y, img_xsize, img_ysize );
  if ( src == 0 ) return;

  XPutImage( display, window, gc,
	     src, 0, 0, win_x, win_y, win_xsize, win_ysize );
  XDestroyImage( src );
}



XImage *XCreateImageFromData
  _P9 (( Display *, display   ),
       ( long     , win_xsize ),
       ( long     , win_ysize ),
       ( long     , type      ),
       ( char **  , data      ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  XImage *src;
  long plane;

  plane  = DisplayPlanes( display, DefaultScreen( display ) );

  XImageSetErrorPorpagate();
  XImageSetLookupTable();

  switch( plane )
    {
    case 1:
      src = XCreateImageFromData_1Plane( display, win_xsize, win_ysize,
					 type, data, img_x, img_y,
					 img_xsize, img_ysize );
      break;

    case 8:
      src = XCreateImageFromData_8Planes( display, win_xsize, win_ysize,
					  type, data, img_x, img_y,
					  img_xsize, img_ysize );
      break;

    case 16:
      src = XCreateImageFromData_16Planes( display, win_xsize, win_ysize,
					   type, data, img_x, img_y,
					   img_xsize, img_ysize );
      break;

    case 24:
      src = XCreateImageFromData_24Planes( display, win_xsize, win_ysize,
					   type, data, img_x, img_y,
					   img_xsize, img_ysize );
      break;

    default:
      fprintf(stderr,
	      "error:XCreateImageFromData:I don't know this display type.\n" );
      return 0;
    }

  return src;
}



void XShowImage
  _P12 (( Display *, display   ),
	( Window   , window    ),
	( GC       , gc        ),
	( image    , img       ),
	( long     , win_x     ),
	( long     , win_y     ),
	( long     , win_xsize ),
	( long     , win_ysize ),
	( long     , img_x     ),
	( long     , img_y     ),
	( long     , img_xsize ),
	( long     , img_ysize ))
{
  XDrawImage( display, window, gc, img->type, img->data,
	      win_x, win_y, win_xsize, win_ysize,
	      img_x, img_y, img_xsize, img_ysize );
}



void XShowImagePartOfImage
  _P8 (( Display *, display   ),
       ( Window   , window    ),
       ( GC       , gc        ),
       ( image    , img       ),
       ( long     , img_x     ),
       ( long     , img_y     ),
       ( long     , img_xsize ),
       ( long     , img_ysize ))
{
  Window root;
  int x, y;
  unsigned int xsize, ysize, border, depth;

  XGetGeometry( display, window, &root,
	        &x, &y, &xsize, &ysize, &border, &depth );

  XDrawImage( display, window, gc, img->type, img->data,
	      0, 0, xsize, ysize, img_x, img_y, img_xsize, img_ysize );
}



void XShowImagePartOfWindow
  _P8 (( Display *, display   ),
       ( Window   , window    ),
       ( GC       , gc        ),
       ( image    , img       ),
       ( long     , win_x     ),
       ( long     , win_y     ),
       ( long     , win_xsize ),
       ( long     , win_ysize ))
{
  XDrawImage( display, window, gc, img->type, img->data,
	      win_x, win_y, win_xsize, win_ysize,
	      0, 0, img->xsize, img->ysize );
}



void XShowImageFull
  _P4 (( Display *, display   ),
       ( Window   , window    ),
       ( GC       , gc        ),
       ( image    , img       ))
{
  Window root;
  int x, y;
  unsigned int xsize, ysize, border, depth;

  XGetGeometry( display, window, &root,
	        &x, &y, &xsize, &ysize, &border, &depth );

  XDrawImage( display, window, gc, img->type, img->data,
	      0, 0, xsize, ysize, 0, 0, img->xsize, img->ysize );
}



uchar __XEPT_90[ 256 ];
uchar __XEPT_45[ 256 ];

void XImageSetErrorPorpagate()
{
  int i;

  for ( i = 0; i < 256; i++ )
    {
      __XEPT_90[i] = 7 * i / 22; /* ��, �� */
      __XEPT_45[i] = 2 * i / 22; /* ����, ���� */
    }
}



uchar XLUT_PC_UChar3[ RMAX ][ GMAX ][ BMAX ];

uchar XLUT_PC_UChar[ 256 ];
uchar XLUT_GS_UChar[ 256 ];
uchar XLUT_SG_UChar[ 256 ];

uchar XLUT_PCR[ 256 ];
uchar XLUT_PCG[ 256 ];
uchar XLUT_PCB[ 256 ];
uchar XLUT_PCRerr[ RMAX ];
uchar XLUT_PCGerr[ GMAX ];
uchar XLUT_PCBerr[ BMAX ];

void XImageSetLookupTable()
{
  static long XLookupTable_initialized = 0;
  int i, r, g, b;

  if ( XLookupTable_initialized ) return;

  for ( i = 0; i < 256; i++ )
    XLUT_PC_UChar[ i ] = MMAX * i / 256 + MBASE;

  for ( i = 0; i < 256; i++ )
    XLUT_GS_UChar[ i ] = GrayMax * i / 256 + GrayBase;

  for ( i = 0; i < 256; i++ )
    XLUT_SG_UChar[ i ] = i;

  for ( r = 0; r < RMAX; r++ )
    for ( g = 0; g < GMAX; g++ )
      for ( b = 0; b < BMAX; b++ )
	XLUT_PC_UChar3[ r ][ g ][ b ] = r * GMAX * BMAX + g * BMAX + b + CBASE;

  for ( i = 0; i < 256; i++ )
    {
      XLUT_PCR[ i ] = RMAX * i / 256;
      XLUT_PCG[ i ] = GMAX * i / 256;
      XLUT_PCB[ i ] = BMAX * i / 256;
    }

  for ( r = 0; r < RMAX; r++ )
    XLUT_PCRerr[ r ] = 256 * r / RMAX;

  for ( g = 0; g < GMAX; g++ )
    XLUT_PCGerr[ g ] = 256 * g / GMAX;

  for ( b = 0; b < BMAX; b++ )
    XLUT_PCBerr[ b ] = 256 * b / BMAX;

  XLookupTable_initialized = 1;
}



/*
 * ��٥�Υ��顼�ޥåפ�����
 */
#include <math.h>
#include <stdlib.h>

uchar3 *XImageMakeLabelColormap _P2 ((long, label_max), (char *, env))
{
  long max_color, smax, reverse = 0;
  uchar3 *cmap;
  long x;

  if (env == 0) return 0;
  max_color = 0;
  if (strcmp(env,"all") == 0)
    max_color = label_max;
  else
  if (strcmp(env,"feature") == 0)
    {reverse = 1; max_color = 1.5*label_max - 1;}
  else
  if (strlen(env) >= 1) max_color = atoi(env);
  if (max_color <= 0) max_color = 12;
  max_color += 1;

  cmap = typenew1(label_max + 3, uchar3);
  smax = label_max / max_color + 1;
  for (x = 1; x <= label_max; x++)
    {
      double theta;
      double s;
      int ti, si;
      double r,g,b;

      si = x / max_color;
      s = 1 - (double)si / smax;

      ti = (x - 1) % max_color;
      theta = 2 * M_PI * (ti + (double)si/smax) / max_color;

      if (theta <= 2*M_PI/3) /* R--G */
	{
	  b = 0;
	  r = cos(theta) + sin(theta) / tan(M_PI/3.0);
	  g = cos(2*M_PI/3.0-theta) + sin(2*M_PI/3.0-theta) / tan(M_PI/3.0);
	  if (s < 0.5) { b += s; } else { r *= s; g *= s; }
	}
      else
      if (4*M_PI/3 <= theta) /* R--B */
	{
	  theta -= 4*M_PI/3;
	  g = 0;
	  b = cos(theta) + sin(theta) / tan(M_PI/3.0);
	  r = cos(2*M_PI/3.0-theta) + sin(2*M_PI/3.0-theta) / tan(M_PI/3.0);
	  if (s < 0.5) { g += s; } else { r *= s; b *= s; }
	}
      else /* B--G */
	{
	  theta -= 2*M_PI/3;
	  r = 0;
	  g = cos(theta) + sin(theta) / tan(M_PI/3.0);
	  b = cos(2*M_PI/3.0-theta) + sin(2*M_PI/3.0-theta) / tan(M_PI/3.0);
	  if (s < 0.5) { r += s; } else { b *= s; g *= s; }
	}
      r = 255 * r;
      g = 255 * g;
      b = 255 * b;

      if (r > 255) r = 255; else if (r < 0) r = 0;
      if (g > 255) g = 255; else if (g < 0) g = 0;
      if (b > 255) b = 255; else if (b < 0) b = 0;

      if (reverse)
	{
	  cmap[x].at[0] = b;
	  cmap[x].at[1] = g;
	  cmap[x].at[2] = r;
	}
      else
	{
	  cmap[x].at[0] = r;
	  cmap[x].at[1] = g;
	  cmap[x].at[2] = b;
	}
    }
  return cmap;
}
